const API_BASE_URL = "https://tinwork-catty-lesser.ngrok-free.dev";

const serviceEndpoints = {
  restaurants: "/api/restaurants",
  cafes: "/api/cafes",
  pharmacies: "/api/pharmacies",
  stores: "/api/stores",
};

let currentService = "";
let currentStoreId = null;
let cart = [];

async function apiRequest(path, options = {}) {
  const response = await fetch(API_BASE_URL + path, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      "ngrok-skip-browser-warning": "true",
      ...(options.headers || {}),
    },
  });

  const raw = await response.text();

  let data;

  try {
    data = JSON.parse(raw);
  } catch {
    throw new Error("السيرفر لم يرجع بيانات JSON صحيحة");
  }

  if (!response.ok) {
    throw new Error(data.error || data.message || "حدث خطأ في السيرفر");
  }

  return data;
}

function text(value) {
  const node = document.createElement("div");
  node.textContent = value == null ? "" : String(value);
  return node.innerHTML;
}

function icon(service) {
  return (
    {
      restaurants: "🍽️",
      cafes: "☕",
      pharmacies: "✚",
      stores: "🛍️",
    }[service] || "🛍️"
  );
}

function label(service) {
  return (
    {
      restaurants: "المطاعم",
      cafes: "المقاهي",
      pharmacies: "الصيدليات",
      stores: "المتاجر",
    }[service] || "الجهات"
  );
}

function asArray(data) {
  if (Array.isArray(data)) {
    return data;
  }

  if (Array.isArray(data.data)) {
    return data.data;
  }

  if (Array.isArray(data.stores)) {
    return data.stores;
  }

  return [];
}

async function showServiceStores(service) {
  currentService = service;

  const panel = document.getElementById("restaurantPanel");
  const title = document.getElementById("restaurantTitle");
  const list = document.getElementById("restaurantList");
  const menu = document.getElementById("restaurantMenu");

  panel.classList.add("show");

  const language =
    localStorage.getItem("dallLanguage") || "ar";

  const serviceNames = {
    ar: {
      restaurants: "المطاعم",
      cafes: "المقاهي",
      pharmacies: "الصيدليات",
      stores: "المتاجر",
    },
    en: {
      restaurants: "Restaurants",
      cafes: "Cafes",
      pharmacies: "Pharmacies",
      stores: "Stores",
    },
    ur: {
      restaurants: "ریستوران",
      cafes: "کیفے",
      pharmacies: "فارمیسی",
      stores: "دکانیں",
    },
    id: {
      restaurants: "Restoran",
      cafes: "Kafe",
      pharmacies: "Apotek",
      stores: "Toko",
    },
  };

  const currentServiceName =
    serviceNames[language]?.[service] ||
    serviceNames.ar[service];

  title.textContent =
    language === "en"
      ? "Loading " + currentServiceName + "..."
      : language === "ur"
        ? currentServiceName + " لوڈ ہو رہے ہیں..."
        : language === "id"
          ? "Memuat " + currentServiceName + "..."
          : "جاري تحميل " + currentServiceName + "...";

  list.innerHTML = "<p>جاري تحميل البيانات...</p>";
  menu.innerHTML = "";

  try {
    const stores = asArray(
      await apiRequest(serviceEndpoints[service]),
    );

    title.textContent = currentServiceName;

    if (!stores.length) {
      list.innerHTML =
        language === "en"
          ? "<p>No places are currently available.</p>"
          : language === "ur"
            ? "<p>فی الحال کوئی جگہ دستیاب نہیں۔</p>"
            : language === "id"
              ? "<p>Tidak ada tempat yang tersedia saat ini.</p>"
              : "<p>لا توجد جهات متاحة حاليًا.</p>";

      return;
    }

    list.innerHTML = stores
      .map((store) => {
        const storeName =
          language === "en"
            ? store.name_en || store.name || "Store"
            : language === "ur"
              ? store.name_ur || store.name || "دکان"
              : language === "id"
                ? store.name_id || store.name || "Toko"
                : store.name || "بدون اسم";

        const storeLocation =
          store.location || "الحرمين";

        return `
          <button
            class="restaurant-card"
            type="button"
            onclick="showStoreMenu(${Number(store.store_id)})"
          >
            <span class="restaurant-icon">
              ${icon(service)}
            </span>

            <strong>${text(storeName)}</strong>

            <small>${text(storeLocation)}</small>
          </button>
        `;
      })
      .join("");
  } catch (error) {
    list.innerHTML =
      "<p>تعذر تحميل البيانات: " +
      text(error.message) +
      "</p>";
  }
}


async function showStoreMenu(storeId) {
  currentStoreId = Number(storeId);

  const menu = document.getElementById("restaurantMenu");

  menu.innerHTML = "<p>جاري تحميل المنيو...</p>";

  try {
    const meals = asArray(
      await apiRequest("/api/meals/" + encodeURIComponent(storeId)),
    );

    const available = meals.filter(
      (meal) => Number(meal.availability) !== 0,
    );

    if (!available.length) {
      menu.innerHTML = "<p>لا توجد منتجات متاحة حاليًا.</p>";
      return;
    }

    const language =
      localStorage.getItem("dallLanguage") || "ar";

    function getMealName(meal) {
      if (language === "en") {
        return meal.name_en || meal.name || "Meal";
      }

      if (language === "ur") {
        return meal.name_ur || meal.name || "کھانا";
      }

      if (language === "id") {
        return meal.name_id || meal.name || "Makanan";
      }

      return meal.name || "وجبة";
    }

    function getMealDescription(meal) {
      if (language === "en") {
        return meal.des_en || meal.des || "";
      }

      if (language === "ur") {
        return meal.des_ur || meal.des || "";
      }

      if (language === "id") {
        return meal.des_id || meal.des || "";
      }

      return meal.des || "";
    }

    menu.innerHTML = `
      <h4 class="menu-heading">المنيو</h4>

      <div class="menu-list">
        ${available
          .map((meal) => {
            const mealName = getMealName(meal);
            const mealDescription = getMealDescription(meal);
            const mealPrice = Number.parseFloat(meal.price) || 0;

            return `
              <div class="menu-row">
                <span class="menu-icon">
                  ${icon(currentService)}
                </span>

                <div class="menu-info">
                  <strong>${text(mealName)}</strong>
                  <small>${text(mealDescription)}</small>
                </div>

                <span class="menu-price">
                  ${mealPrice.toFixed(2)} ر.س
                </span>

                <button
                  class="menu-add"
                  type="button"
                  onclick="addToCart(
                    ${Number(meal.meal_id)},
                    '${String(mealName).replaceAll("'", "\\'")}',
                    ${mealPrice}
                  )"
                >
                  +
                </button>
              </div>
            `;
          })
          .join("")}
      </div>
    `;

    setTimeout(() => {
      menu.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }, 100);
  } catch (error) {
    menu.innerHTML =
      "<p>تعذر تحميل المنيو: " + text(error.message) + "</p>";
  }
}


function addToCart(mealId, name, price) {
  const item = cart.find((entry) => entry.meal_id === mealId);

  if (item) {
    item.quantity += 1;
  } else {
    cart.push({
      meal_id: mealId,
      store_id: currentStoreId,
      name,
      price: Number(price),
      quantity: 1,
    });
  }

  renderCartButton();
  showToast("تمت إضافة " + name + " إلى السلة");
}

function renderCartButton() {
  let button = document.getElementById("cartButton");

  if (!button) {
    button = document.createElement("button");
    button.id = "cartButton";
    button.className = "cart-button";
    button.type = "button";
    button.onclick = showCart;
    document.body.appendChild(button);
  }

  const totalItems = cart.reduce(
    (sum, item) => sum + item.quantity,
    0,
  );

  button.textContent = `🛍 السلة (${totalItems})`;
  button.classList.add("show");
}

async function showCart() {
  let modal = document.getElementById("cartModal");

  if (!modal) {
    modal = document.createElement("div");
    modal.id = "cartModal";
    modal.className = "cart-modal";
    document.body.appendChild(modal);
  }

  const total = cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0,
  );

  let points = [];

  try {
    points = asArray(await apiRequest("/api/pickup-points"));
  } catch {
    points = [];
  }

  modal.innerHTML = `
    <div class="cart-box">
      <button
        class="cart-close"
        type="button"
        onclick="closeCart()"
      >
        ×
      </button>

      <h3>سلة الطلب</h3>

      ${
        cart.length
          ? `
            <div class="cart-items">
              ${cart
                .map(
                  (item, index) => `
                    <div class="cart-item">
                      <span>
                        ${text(item.name)} × ${item.quantity}
                      </span>

                      <b>
                        ${(item.price * item.quantity).toFixed(2)} ر.س
                      </b>

                      <button
                        type="button"
                        onclick="removeFromCart(${index})"
                      >
                        −
                      </button>
                    </div>
                  `,
                )
                .join("")}
            </div>

            <select
              id="pickupPointSelect"
              class="pickup-select"
            >
              <option value="">
                اختاري نقطة الاستلام
              </option>

              ${points
                .map(
                  (point) => `
                    <option value="${Number(point.pickup_point_id)}">
                      ${text(point.name)} - ${text(point.location)}
                    </option>
                  `,
                )
                .join("")}
            </select>

            <div class="cart-total">
              <strong>الإجمالي</strong>
              <strong>${total.toFixed(2)} ر.س</strong>
            </div>

            <button
              class="checkout-button"
              type="button"
              onclick="submitOrder()"
            >
              تأكيد الطلب
            </button>
          `
          : "<p>السلة فارغة.</p>"
      }
    </div>
  `;

  modal.classList.add("show");
}

function removeFromCart(index) {
  if (cart[index].quantity > 1) {
    cart[index].quantity -= 1;
  } else {
    cart.splice(index, 1);
  }

  if (!cart.length) {
    document.getElementById("cartButton")?.remove();
    closeCart();
  } else {
    showCart();
  }
}

function closeCart() {
  document.getElementById("cartModal")?.classList.remove("show");
}

async function submitOrder() {
  const userData = JSON.parse(
    localStorage.getItem("dallUser") || "{}",
  );

  const userId = Number(
    localStorage.getItem("userId") ||
      userData.userId ||
      userData.user_id ||
      0,
  );

  const pickupPointId = Number(
    document.getElementById("pickupPointSelect")?.value || 0,
  );

  if (!userId) {
    showToast("سجلي الدخول أولًا قبل تأكيد الطلب");
    return;
  }

  if (!currentStoreId || !cart.length) {
    showToast("السلة فارغة");
    return;
  }

  if (!pickupPointId) {
    showToast("اختاري نقطة الاستلام");
    return;
  }

  try {
    const result = await apiRequest("/api/orders", {
      method: "POST",

      body: JSON.stringify({
        user_id: userId,
        store_id: currentStoreId,
        pickup_point_id: pickupPointId,

        items: cart.map((item) => ({
          meal_id: item.meal_id,
          quantity: item.quantity,
          unit_price: item.price,
        })),
      }),
    });

    showOrderConfirmation(result);

    cart = [];

    document.getElementById("cartButton")?.remove();

    closeCart();
  } catch (error) {
    showToast("تعذر إرسال الطلب: " + error.message);
  }
}

function showOrderConfirmation(result) {
  let modal = document.getElementById("orderConfirmation");

  if (!modal) {
    modal = document.createElement("div");
    modal.id = "orderConfirmation";
    modal.className = "order-confirmation";
    document.body.appendChild(modal);
  }

  const orderId =
    result.orderId ??
    result.order_id ??
    "-";

  const pickupPin =
    result.pickup_pin ??
    result.pickupPin ??
    "-";

  modal.innerHTML = `
    <div
      class="order-confirmation-box"
      role="dialog"
      aria-modal="true"
      aria-labelledby="orderConfirmationTitle"
    >
      <button
        class="cart-close"
        type="button"
        onclick="closeOrderConfirmation()"
        aria-label="إغلاق"
      >
        ×
      </button>

      <div class="success-mark">
        ✓
      </div>

      <h3 id="orderConfirmationTitle">
        تم إرسال طلبك بنجاح
      </h3>

      <p>
        احتفظي بالبيانات التالية عند الاستلام:
      </p>

      <div class="order-details">
        <div>
          <span>رقم الطلب</span>
          <strong>${text(orderId)}</strong>
        </div>

        <div>
          <span>رمز الاستلام PIN</span>
          <strong>${text(pickupPin)}</strong>
        </div>
      </div>

      <small>
        الطلب مرتبط بحسابك ورقم الجوال المسجل فيه.
      </small>

      <button
        class="primary-button full-btn"
        type="button"
        onclick="closeOrderConfirmation()"
      >
        حسنًا
      </button>
    </div>
  `;

  modal.classList.add("show");
}

function closeOrderConfirmation() {
  document
    .getElementById("orderConfirmation")
    ?.classList.remove("show");
}

function showToast(message) {
  const toast = document.getElementById("siteToast");

  if (!toast) {
    return;
  }

  toast.textContent = message;
  toast.classList.add("show");

  setTimeout(() => {
    toast.classList.remove("show");
  }, 3200);
}

function closeRestaurants() {
  document
    .getElementById("restaurantPanel")
    ?.classList.remove("show");
}

window.showStoreMenu = showStoreMenu;
window.closeRestaurants = closeRestaurants;
window.addToCart = addToCart;
window.showCart = showCart;
window.closeCart = closeCart;
window.removeFromCart = removeFromCart;
window.submitOrder = submitOrder;
window.closeOrderConfirmation = closeOrderConfirmation;

window.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("a.category").forEach((category) => {
    const value = category.textContent;

    const service = value.includes("المطاعم")
      ? "restaurants"
      : value.includes("المقاهي")
        ? "cafes"
        : value.includes("الصيدليات")
          ? "pharmacies"
          : value.includes("المتاجر")
            ? "stores"
            : "";

    if (service) {
      category.addEventListener("click", (event) => {
        event.preventDefault();
        showServiceStores(service);
      });
    }
  });
});
window.addEventListener("dallLanguageChanged", async () => {
  if (!currentService) {
    return;
  }

  const selectedStoreId = currentStoreId;

  await showServiceStores(currentService);

  if (selectedStoreId) {
    await showStoreMenu(selectedStoreId);
  }
});
window.addEventListener("dallLanguageChanged", async () => {
  if (!currentService) {
    return;
  }

  const selectedStoreId = currentStoreId;

  await showServiceStores(currentService);

  if (selectedStoreId) {
    await showStoreMenu(selectedStoreId);
  }
});
