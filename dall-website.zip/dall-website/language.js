const dallTranslations = {
  ar: {
    title: "دالّ | طلبك جاهز عند وصولك",
    services: "الخدمات",
    login: "تسجيل الدخول",
    register: "إنشاء حساب",
    restaurants: "المطاعم",
    cafes: "المقاهي",
    pharmacies: "الصيدليات",
    stores: "المتاجر",
    choose: "اختاري ما يناسب رحلتك",
    language: "اللغة",
    heroEyebrow: "تجربة أذكى في الحرمين",
heroTitle: "اطلب الآن،",
heroSubtitle: "واستلمها عند وصولك.",
heroText:
  "دالّ يجمع المطاعم والمقاهي والصيدليات والمتاجر في مكان واحد، لتصبح طلباتك أسهل وأسرع.",
exploreServices: "استكشف الخدمات",

  },
  en: {
    title: "Dall | Your order is ready when you arrive",
    services: "Services",
    login: "Login",
    register: "Create account",
    restaurants: "Restaurants",
    cafes: "Cafes",
    pharmacies: "Pharmacies",
    stores: "Stores",
    choose: "Choose what you need",
    language: "Language",
    heroEyebrow: "A smarter experience in the Holy Mosques",
heroTitle: "Order now,",
heroSubtitle: "and pick it up when you arrive.",
heroText:
  "Dall brings restaurants, cafes, pharmacies, and stores together in one place, making your orders easier and faster.",
exploreServices: "Explore services",

  },
  ur: {
    title: "دالّ | آپ کے پہنچنے پر آپ کا آرڈر تیار",
    services: "خدمات",
    login: "لاگ ان",
    register: "اکاؤنٹ بنائیں",
    restaurants: "ریستوران",
    cafes: "کیفے",
    pharmacies: "فارمیسی",
    stores: "دکانیں",
    choose: "اپنی ضرورت منتخب کریں",
    language: "زبان",
    heroEyebrow: "حرمین شریفین میں ایک بہتر تجربہ",
heroTitle: "ابھی آرڈر کریں،",
heroSubtitle: "اور پہنچنے پر وصول کریں۔",
heroText:
  "دال ریستوران، کیفے، فارمیسی اور دکانوں کو ایک جگہ جمع کرتا ہے تاکہ آپ کے آرڈرز آسان اور تیز ہوں۔",
exploreServices: "خدمات دیکھیں",

  },
  id: {
    title: "Dall | Pesanan siap saat Anda tiba",
    services: "Layanan",
    login: "Masuk",
    register: "Buat akun",
    restaurants: "Restoran",
    cafes: "Kafe",
    pharmacies: "Apotek",
    stores: "Toko",
    choose: "Pilih yang Anda butuhkan",
    language: "Bahasa",
    heroEyebrow: "Pengalaman lebih cerdas di Dua Masjid Suci",
heroTitle: "Pesan sekarang,",
heroSubtitle: "dan ambil saat Anda tiba.",
heroText:
  "Dall menggabungkan restoran, kafe, apotek, dan toko dalam satu tempat agar pesanan Anda lebih mudah dan cepat.",
exploreServices: "Jelajahi layanan",

  },
};
function setDallLanguage(language) {
  const t = dallTranslations[language] || dallTranslations.ar;
  document.documentElement.lang = language;
  document.documentElement.dir =
    language === "ar" || language === "ur" ? "rtl" : "ltr";
  document.title = t.title;
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.dataset.i18n;
    if (t[key]) el.textContent = t[key];
  });
  localStorage.setItem("dallLanguage", language);
  window.dispatchEvent(
  new CustomEvent("dallLanguageChanged", {
    detail: language,
  }),
);
}
window.addEventListener("DOMContentLoaded", () => {
  let select = document.getElementById("languageSelect");
  if (!select) {
    select = document.createElement("select");
    select.id = "languageSelect";
    select.className = "language-select";
    select.innerHTML =
      '<option value="ar">العربية</option><option value="en">English</option><option value="ur">اردو</option><option value="id">Bahasa Indonesia</option>';
    document.querySelector(".nav")?.appendChild(select);
  }
  const saved = localStorage.getItem("dallLanguage") || "ar";
  select.value = saved;
  setDallLanguage(saved);
  select.addEventListener("change", () => setDallLanguage(select.value));
});