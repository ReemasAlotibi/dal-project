const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// 1. إعداد الاتصال بقاعدة البيانات
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '', // كلمة المرور فارغة افتراضياً في XAMPP
    database: 'dal_system'
});

// 2. اختبار الاتصال
db.connect((err) => {
    if (err) {
        console.error('خطأ في الاتصال بقاعدة البيانات:', err);
        return;
    }
    console.log('✅ تم الاتصال بقاعدة البيانات بنجاح!');
});

// 3. أول API: تسجيل مستخدم جديد
app.post('/api/register', async (req, res) => {
    const { name, email, phone, password } = req.body;
    try {
        const validationError = validateInput(name, email, phone, password);
        if (validationError) {
            return res.status(400).json({ error: validationError });
        }
        const hashedPassword = await bcrypt.hash(password, 10);
        const sql = 'INSERT INTO Users (name, email, phone, password) VALUES (?, ?, ?, ?)';
        db.query(sql, [name, email, phone, hashedPassword], (err, result) => {
            if (err) {
                return res.status(500).json({ error: err.message });
            }
            res.status(201).json({ message: 'تم تسجيل المستخدم بنجاح!', userId: result.insertId });
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// مسار المطاعم
app.get('/api/restaurants', (req, res) => {
    const sql = 'SELECT s.*, c.name AS category_name FROM Stores s LEFT JOIN Categories c ON s.category_id = c.category_id WHERE s.category_id = 1 AND s.status = "active"';
    db.query(sql, (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(result);
    });
});

// مسار المقاهي
app.get('/api/cafes', (req, res) => {
    const sql = 'SELECT s.*, c.name AS category_name FROM Stores s LEFT JOIN Categories c ON s.category_id = c.category_id WHERE s.category_id = 2 AND s.status = "active"';
    db.query(sql, (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(result);
    });
});

// مسار الصيدليات
app.get('/api/pharmacies', (req, res) => {
    const sql = 'SELECT s.*, c.name AS category_name FROM Stores s LEFT JOIN Categories c ON s.category_id = c.category_id WHERE s.category_id = 3 AND s.status = "active"';
    db.query(sql, (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(result);
    });
});

// مسار التصنيفات
app.get('/api/categories', (req, res) => {
    db.query('SELECT * FROM Categories', (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(result);
    });
});

// مسار كل المتاجر
app.get('/api/stores', (req, res) => {
    const sql = 'SELECT s.*, c.name AS category_name FROM Stores s LEFT JOIN Categories c ON s.category_id = c.category_id WHERE s.status = "active"';
    db.query(sql, (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(result);
    });
});

// مسار نقاط الاستلام
app.get('/api/pickup-points', (req, res) => {
    db.query('SELECT * FROM Pickup_Points WHERE status = "active"', (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(result);
    });
});

// مسار منيو متجر
app.get('/api/meals/:store_id', (req, res) => {
    const sql = 'SELECT * FROM Meals WHERE store_id = ? AND availability = TRUE';
    db.query(sql, [req.params.store_id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(result);
    });
});

// مسار المباني المركزية
app.get('/api/buildings', (req, res) => {
    db.query('SELECT * FROM Buildings WHERE status = "active"', (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(result);
    });
});

// مسار الفواتير
app.get('/api/invoices/:user_id', (req, res) => {
    const sql = 'SELECT i.*, s.name AS store_name FROM Invoices i JOIN Stores s ON i.store_id = s.store_id WHERE i.user_id = ? ORDER BY i.issued_at DESC';
    db.query(sql, [req.params.user_id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(result);
    });
});
// ============ API: تسجيل الدخول ============
app.post('/api/login', (req, res) => {
    const { email, password } = req.body;

    const userSql = 'SELECT * FROM Users WHERE email = ?';
    db.query(userSql, [email], async (err, userResult) => {
        if (err) return res.status(500).json({ error: err.message });

        if (userResult.length > 0) {
            const user = userResult[0];
            const match = await bcrypt.compare(password, user.password);
            if (match) {
                return res.json({
                    message: 'تم تسجيل الدخول بنجاح',
                    userType: 'user',
                    userId: user.user_id,
                    name: user.name
                });
            }
        }

        const ownerSql = 'SELECT * FROM Store_Owners WHERE email = ?';
        db.query(ownerSql, [email], async (err, ownerResult) => {
            if (err) return res.status(500).json({ error: err.message });

            if (ownerResult.length > 0) {
                const owner = ownerResult[0];
                const match = await bcrypt.compare(password, owner.password);
                if (match) {
                    return res.json({
                        message: 'تم تسجيل الدخول بنجاح',
                        userType: 'owner',
                        ownerId: owner.owner_id,
                        name: owner.name
                    });
                }
            }
            res.status(401).json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' });
        });
    });
});
// ============ API: تسجيل سائق جديد ============
app.post('/api/register-driver', async (req, res) => {
    const { name, email, phone, password, vehicle_type, vehicle_plate } = req.body;
    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const sql = 'INSERT INTO Drivers (name, email, phone, password, vehicle_type, vehicle_plate) VALUES (?, ?, ?, ?, ?, ?)';
        db.query(sql, [name, email, phone, hashedPassword, vehicle_type, vehicle_plate], (err, result) => {
            if (err) return res.status(500).json({ error: err.message });
            res.status(201).json({ message: 'تم تسجيل السائق بنجاح!', driverId: result.insertId });
        });
    } catch (error) { res.status(500).json({ error: error.message }); }
});

// ============ API: تسجيل دخول السائق ============
app.post('/api/login-driver', (req, res) => {
    const { email, password } = req.body;
    db.query('SELECT * FROM Drivers WHERE email = ?', [email], async (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        if (result.length === 0) return res.status(401).json({ error: 'البريد أو كلمة المرور خطأ' });
        const driver = result[0];
        const match = await bcrypt.compare(password, driver.password);
        if (match) {
            return res.json({ message: 'تم تسجيل الدخول', userType: 'driver', driverId: driver.driver_id, name: driver.name });
        }
        res.status(401).json({ error: 'البريد أو كلمة المرور خطأ' });
    });
});

// ============ API: جلب كل السائقين (للمدير) ============
app.get('/api/drivers', (req, res) => {
    db.query('SELECT driver_id, name, email, phone, vehicle_type, vehicle_plate, status, rating FROM Drivers', (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(result);
    });
});

// ============ API: تسجيل دخول المدير ============
app.post('/api/login-admin', (req, res) => {
    const { email, password } = req.body;
    db.query('SELECT * FROM Admins WHERE email = ?', [email], async (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        if (result.length === 0) return res.status(401).json({ error: 'البريد أو كلمة المرور خطأ' });
        const admin = result[0];
        const match = await bcrypt.compare(password, admin.password);
        if (match) {
            return res.json({ message: 'تم تسجيل الدخول', userType: 'admin', adminId: admin.admin_id, name: admin.name });
        }
        res.status(401).json({ error: 'البريد أو كلمة المرور خطأ' });
    });
});

// ============ API: إحصائيات المدير ============
app.get('/api/admin/stats', (req, res) => {
    const stats = {};
    db.query('SELECT COUNT(*) AS total_users FROM Users', (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        stats.totalUsers = result[0].total_users;
        db.query('SELECT COUNT(*) AS total_stores FROM Stores', (err, result) => {
            stats.totalStores = result[0].total_stores;
            db.query('SELECT COUNT(*) AS total_orders FROM Orders', (err, result) => {
                stats.totalOrders = result[0].total_orders;
                db.query('SELECT COUNT(*) AS total_drivers FROM Drivers', (err, result) => {
                    stats.totalDrivers = result[0].total_drivers;
                    res.json(stats);
                });
            });
        });
    });
});

// ============ API: تسجيل مدير جديد ============
app.post('/api/register-admin', async (req, res) => {
    const { name, email, password } = req.body;
    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const sql = 'INSERT INTO Admins (name, email, password, role) VALUES (?, ?, ?, "admin")';
        db.query(sql, [name, email, hashedPassword], (err, result) => {
            if (err) return res.status(500).json({ error: err.message });
            res.status(201).json({ message: 'تم تسجيل المدير بنجاح!', adminId: result.insertId });
        });
    } catch (error) { res.status(500).json({ error: error.message }); }
});


// ============ API: إرسال طلب جديد ============
app.post('/api/orders', (req, res) => {
    const { user_id, store_id, pickup_point_id, items } = req.body;

    if (!items || items.length === 0) {
        return res.status(400).json({ error: 'السلة فارغة' });
    }

    let total = 0;
    items.forEach(item => {
        total += item.quantity * item.unit_price;
    });

    // توليد رقم PIN عشوائي (4 أرقام)
    const pickupPin = Math.floor(1000 + Math.random() * 9000).toString();

    const orderSql = 'INSERT INTO Orders (user_id, store_id, pickup_point_id, order_time, total_amount, status, pickup_pin) VALUES (?, ?, ?, NOW(), ?, "pending", ?)';

    db.query(orderSql, [user_id, store_id, pickup_point_id, total, pickupPin], (err, orderResult) => {
        if (err) return res.status(500).json({ error: err.message });

        const orderId = orderResult.insertId;

        const itemsData = items.map(item => [
            orderId,
            item.meal_id,
            item.quantity,
            item.unit_price,
            item.quantity * item.unit_price
        ]);

        const itemsSql = 'INSERT INTO Order_Items (order_id, meal_id, quantity, unit_price, subtotal) VALUES ?';
        db.query(itemsSql, [itemsData], (err, itemsResult) => {
            if (err) return res.status(500).json({ error: err.message });

            res.status(201).json({
                message: 'تم إرسال الطلب بنجاح!',
                orderId: orderId,
                total: total,
                pickup_pin: pickupPin
            });
        });
    });
});

// ============ API: جلب طلبات المستخدم ============
app.get('/api/orders/:user_id', (req, res) => {
    const sql = 'SELECT o.*, s.name AS store_name FROM Orders o JOIN Stores s ON o.store_id = s.store_id WHERE o.user_id = ? ORDER BY o.order_time DESC';
    db.query(sql, [req.params.user_id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(result);
    });
});

// ============ API: تعيين سائق لطلب ============
app.put('/api/orders/:order_id/assign-driver', (req, res) => {
    const { order_id } = req.params;
    const { driver_id } = req.body;

    if (!driver_id) {
        return res.status(400).json({ error: 'يجب تحديد رقم السائق' });
    }

    // 1. التأكد أن السائق موجود ومتاح
    db.query('SELECT * FROM Drivers WHERE driver_id = ? AND status = "available"', [driver_id], (err, driverResult) => {
        if (err) return res.status(500).json({ error: err.message });

        if (driverResult.length === 0) {
            return res.status(404).json({ error: 'السائق غير موجود أو غير متاح حالياً' });
        }

        // 2. تحديث الطلب لربطه بالسائق وتغيير حالته
        const sql = 'UPDATE Orders SET driver_id = ?, status = "preparing" WHERE order_id = ?';
        db.query(sql, [driver_id, order_id], (err, result) => {
            if (err) return res.status(500).json({ error: err.message });

            if (result.affectedRows === 0) {
                return res.status(404).json({ error: 'الطلب غير موجود' });
            }

            // 3. تحديث حالة السائق إلى "مشغول"
            db.query('UPDATE Drivers SET status = "busy" WHERE driver_id = ?', [driver_id]);

            res.json({
                message: 'تم تعيين السائق للطلب بنجاح!',
                order_id: order_id,
                driver_id: driver_id,
                new_status: 'preparing'
            });
        });
    });
});

// دالة التحقق من البيانات
function validateInput(name, email, phone, password) {
    // التحقق من الاسم (كلمتين على الأقل)
    if (!name || name.trim().split(' ').length < 2) {
        return 'الاسم يجب أن يتكون من كلمتين على الأقل';
    }
    // التحقق من الإيميل
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email || !emailRegex.test(email)) {
        return 'البريد الإلكتروني غير صحيح';
    }
    // التحقق من الجوال (10 أرقام تبدأ بـ 05)
    const phoneRegex = /^05\d{8}$/;
    if (!phone || !phoneRegex.test(phone)) {
        return 'رقم الجوال يجب أن يكون 10 أرقام ويبدأ بـ 05';
    }
    // التحقق من كلمة المرور (6 أحرف على الأقل)
    if (!password || password.length < 6) {
        return 'كلمة المرور يجب أن تكون 6 أحرف على الأقل';
    }
    return null; // إذا كل شي تمام
}

// دالة الترجمة التلقائية
function translateData(data) {
    if (Array.isArray(data)) {
        return data.map(item => translateData(item));
    } else if (data !== null && typeof data === 'object') {
        let newData = { ...data };
        if (newData.name_en) newData.name = newData.name_en; // استبدال الاسم بالانجليزي
        if (newData.des_en) newData.des = newData.des_en;   // استبدال الوصف بالانجليزي
        delete newData.name_en; delete newData.name_ur; delete newData.name_id;
        delete newData.des_en; delete newData.des_ur; delete newData.des_id;
        return newData;
    }
    return data;
}

// اعتراض الردود وإضافة الترجمة
app.use((req, res, next) => {
    const originalJson = res.json;
    res.json = function(data) {
        return originalJson.call(this, translateData(data));
    };
    next();
});
// 4. تشغيل الخادم
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`🚀 الخادم يعمل على المنفذ ${PORT}`);
});